import { configureStore } from '@reduxjs/toolkit'
import { combineReducers } from 'redux'
import storage from 'redux-persist/lib/storage';
import { persistReducer, persistStore } from 'redux-persist';
import userReducer from './slice/authSlice'
import notificationSlice from './slice/notificationSlice';

const rootReducer = combineReducers({
  user: userReducer,
  notification:notificationSlice
})

const persistConfig = {
  key: 'ritual_masonic_admin',
  storage,
}

const persistedReducer = persistReducer(persistConfig, rootReducer)

export const store = configureStore({
  reducer: persistedReducer
})

export const persistor = persistStore(store)